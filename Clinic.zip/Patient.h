#ifndef PATIENT_H
#define PATIENT_H

/*
pSick - sickness probability (0 - 100)
disease - probable disease (if pSick >= 0.5)
*/

typedef struct {
    unsigned char pSick;
    unsigned int disease;
    unsigned int waitStart;
    unsigned int number;
    unsigned char directed;
} Patient;


Patient *newPatient(unsigned char pSick, unsigned int disease, unsigned int waitStart, unsigned int number);

void freePatient(Patient **patient);

void printPatient(Patient *patient);


#endif