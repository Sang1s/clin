#include <stdio.h>
#include <stdlib.h>
#include "Patient.h"


Patient *newPatient(unsigned char pSick, unsigned int disease, unsigned int waitStart, unsigned int number) {
    Patient *patient = (Patient *) malloc(sizeof(Patient));
    patient->pSick = pSick;
    patient->disease = disease;
    patient->waitStart = waitStart;
    patient->number = number;
    patient->directed = 0;
    return patient;
}


void freePatient(Patient **patient) {
    free(*patient);
    *patient = NULL;
}


void printPatient(Patient *patient) {
    printf("\nPatient:\npSick = %u,\ndisease = %u,\nwaitStart = %u,\nnumber = %u",
        patient->pSick,
        patient->disease,
        patient->waitStart,
        patient->number
    );
} 