#include "Queue.h"
#include <stdlib.h>

Queue *newQueue() {
    Queue* queue = (Queue*) malloc(sizeof(Queue));
    for (QUEUE_SIZE_TYPE i = 0; i < QUEUE_MAX; ++i) {
       queue->array[i] = NULL;
    }
    queue->front = 0;
    queue->rear = -1;
    queue->itemCount = 0;
}

QUEUE_TYPE *queuePeek(Queue *queue) {
   return queue->array[queue->front];
}

char queueIsEmpty(Queue *queue) {
   return queue->itemCount == 0;
}

char queueIsFull(Queue *queue) {
   return queue->itemCount == QUEUE_MAX;
}

QUEUE_SIZE_TYPE queueLength(Queue *queue) {
   return queue->itemCount;
}  

void enqueue(Queue *queue, QUEUE_TYPE *data) {

   if (!queueIsFull(queue)) {
	
      if (queue->rear == QUEUE_MAX-1) {
        queue->rear = -1;            
      }       

      queue->array[++queue->rear] = data;
      queue->itemCount++;
   }
}

QUEUE_TYPE *dequeue(Queue *queue) {
   QUEUE_TYPE *data = queue->array[queue->front++];

   if (queue->front == QUEUE_MAX) {
      queue->front = 0;
   }

   --queue->itemCount;
   return data;  
}

void freeQueue(Queue **queue) {
   free(*queue);
   queue = NULL;
}

void freeNodeQueue(Queue **queue) {
   QUEUE_TYPE **arr = (*queue)->array;
   for (QUEUE_SIZE_TYPE i; i < QUEUE_MAX; ++i) {
      if (arr[i] != NULL) {
         free(arr[i]);
         arr[i] = NULL;
      }
   }
   freeQueue(queue);
}