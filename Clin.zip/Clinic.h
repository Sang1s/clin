#ifndef CLINIC_H
#define CLINIC_H

#include "Patient.h"
#include "TimedQueue.h"

#define PARAMS_COUNT 8

#define PARAM_TYPE unsigned int

typedef struct TimedQueue {
    Queue *queue;
    PARAM_TYPE time;
} TimedQueue;


char readParams(FILE *paramFile, PARAM_TYPE *params[]);

char arrayHasZero(PARAM_TYPE arrSize, PARAM_TYPE *arr[]);

Patient *acceptNewPatient(PARAM_TYPE queueSize, TimedQueue *timedQueues[], PARAM_TYPE professionCount, PARAM_TYPE *chosenNum);


#endif