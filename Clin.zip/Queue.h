#ifndef QUEUE_H
#define QUEUE_H

#include "Patient.h"

#define QUEUE_MAX 30
#define QUEUE_TYPE Patient
#define QUEUE_SIZE_TYPE unsigned char

typedef struct Queue {
    QUEUE_TYPE *array[QUEUE_MAX];
    QUEUE_SIZE_TYPE front;
    QUEUE_SIZE_TYPE rear;
    QUEUE_SIZE_TYPE itemCount;
} Queue;

Queue *newQueue();

QUEUE_TYPE *queuePeek(Queue *queue);

char queueIsEmpty(Queue *queue);

char queueIsFull(Queue *queue);

QUEUE_SIZE_TYPE queueLength(Queue *queue);

void enqueue(Queue *queue, QUEUE_TYPE *data);

QUEUE_TYPE *dequeue(Queue *queue);

void freeQueue(Queue **queue);

void freePatientQueue(Queue **queue);

#endif