#include "TimedQueue.h"
#include <stdlib.h>


TimedQueue *newTimedQueue(unsigned int decisionTime) {
    TimedQueue *timedQueue = (TimedQueue *) malloc(sizeof(TimedQueue));
    timedQueue->queue = newQueue();
    timedQueue->time = decisionTime;
}


void freeTimedQueue(TimedQueue **timedQueue) {
    //freeNodeQueue(&((*timedQueue)->queue));
    free(*timedQueue);
    *timedQueue = NULL;
}


void initTimedQueues(PARAM_TYPE queuesSize, TimedQueue *timedQueues[], unsigned int decisionTime) {
    for (int i = 0; i < queuesSize; ++i) {
        timedQueues[i] = newTimedQueue(decisionTime);
    }
}


void freeTimedQueues(PARAM_TYPE queuesSize, TimedQueue *timedQueues[]) {
    for (int i = 0; i < queuesSize; ++i) {
    freeTimedQueue(&timedQueues[i]);
    }
}