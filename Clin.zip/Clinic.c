#include "Clinic.h"


char readParams(FILE *paramFile, PARAM_TYPE *params[]) {
    int i;
    for (i = 0; !feof(paramFile) || (i < PARAMS_COUNT); ++i) {
        int hasRead = fscanf(paramFile, "%u%*[^\n]\n", params[i]);
        if (!hasRead) {
            --i;
        }
    }
    // too little params
    if (i < (PARAMS_COUNT - 1)) {
        return 0;
    }
    return 1;
}


char arrayHasZero(PARAM_TYPE arrSize, PARAM_TYPE *arr[]) {
        for (int i = 0; i < arrSize; ++i) {
        if (*arr[i] == 0) {
            return 1;
        }
    }
    return 0;
}


Patient *acceptNewPatient(PARAM_TYPE queueSize, TimedQueue *timedQueues[], PARAM_TYPE professionCount, PARAM_TYPE *chosenNum) {
        // unsigned char pFoundPatient = rand() % 100;
    // if (pFoundPatient < 50) {
    //     return NULL;
    // }
    PARAM_TYPE chosenIndex = rand() % queueSize;
    Queue *chosenQueue = timedQueues[chosenIndex]->queue;
    if (!queueIsFull(chosenQueue)) {
        unsigned char pSick = rand() % 100;
        unsigned int disease = rand() % professionCount + 1;
        Patient *patient = newPatient(pSick, disease, 0, 0);
        *chosenNum = chosenIndex + 1;
        enqueue(chosenQueue, patient);
        return patient;
    }
    else {
        PARAM_TYPE foundIndex = -1;
        for (PARAM_TYPE i = chosenIndex + 1; i < queueSize; ++i) {
            if (!queueIsFull(timedQueues[i]->queue)) {
                foundIndex = i;
            }
        }
        for (PARAM_TYPE i = 0; i < chosenIndex; ++i) {
            if (!queueIsFull(timedQueues[i]->queue)) {
                foundIndex = i;
            }
        }
        if (foundIndex != -1) {
            unsigned char pSick = rand() % 100;
            unsigned int disease = rand() % professionCount + 1;
            Patient *patient = newPatient(pSick, disease, 0, 0);
            *chosenNum = chosenIndex + 1;
            enqueue(timedQueues[foundIndex]->queue, patient);
            return patient;
        }
        else {
            return NULL;
        }
    }
}