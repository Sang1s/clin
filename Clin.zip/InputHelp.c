#include "InputHelp.h"
#include <stdio.h>
#include <string.h>


void cleanStdinBuffer() {
    int c = 0;
    do {
        c = getchar();
    }
    while ((c != '\n') && (c != EOF));
}


void fixFgetsStr(char str[]) {
    str[strlen(str) - 1] = '\0';
}


FILE *inputFile(char type[], char fileMsg[]) {
    FILE *file = NULL;
    printf("\n\nĮveskite %s failą: ", fileMsg);
    char filename[FILENAME_MAX];
    fgets(filename, FILENAME_MAX, stdin);
    fixFgetsStr(filename);
    file = fopen(filename, type);
    if (file == NULL) {
        printf("\n\nĮvestas failas neegzistuoja, išeinama.");
        printf("\nProgramos pabaiga.");
        exit(EXIT_FAILURE);
    }
    else {
        return file;
    }
}