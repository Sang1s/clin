#ifndef TIMED_QUEUE_H
#define TIMED_QUEUE_H

#include "Clinic.h"
#include "Queue.h"

typedef struct TimedQueue {
    Queue *queue;
    PARAM_TYPE time;
} TimedQueue;

typedef struct Patient {
    unsigned char pSick;
    unsigned int disease;
    unsigned int waitStart;
    unsigned int number;
    unsigned char directed;
} Patient;


TimedQueue *newTimedQueue(unsigned int decisionTime);

void freeTimedQueue(TimedQueue **timedQueue);

void initTimedQueues(PARAM_TYPE queuesSize, TimedQueue *timedQueues[], unsigned int decisionTime);

void freeTimedQueues(PARAM_TYPE queuesSize, TimedQueue *timedQueues[]);

#endif