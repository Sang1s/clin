#ifndef INPUT_HELP_H
#define INPUT_HELP_H


void cleanStdinBuffer();

void fixFgetsStr(char str[]);

FILE *inputFile(char type[], char fileMsg[]);


#endif