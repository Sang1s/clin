// Ignas Jogminas 4 gr.

#include "BigInteger.h"
#include "TimedQueue.h"
#include "Patient.h"
#include "Clinic.h"
#include "InputHelp.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// #define PARAMS_COUNT 8

// #define PARAM_TYPE unsigned int


// char readParams(FILE *paramFile, PARAM_TYPE *params[]) {
//     int i;
//     for (i = 0; !feof(paramFile) || (i < PARAMS_COUNT); ++i) {
//         int hasRead = fscanf(paramFile, "%u%*[^\n]\n", params[i]);
//         if (!hasRead) {
//             --i;
//         }
//     }
//     // too little params
//     if (i < (PARAMS_COUNT - 1)) {
//         return 0;
//     }
//     return 1;
// }


// char arrayHasZero(PARAM_TYPE arrSize, PARAM_TYPE *arr[]) {
//     for (int i = 0; i < arrSize; ++i) {
//         if (*arr[i] == 0) {
//             return 1;
//         }
//     }
//     return 0;
// }


// void cleanStdinBuffer() {
//     int c = 0;
//     do {
//         c = getchar();
//     }
//     while ((c != '\n') && (c != EOF));
// }


// // Remove read newline after fgets
// void fixFgetsStr(char str[]) {
//     str[strlen(str) - 1] = '\0';
// }


// // TimedQueue *newTimedQueue(unsigned int decisionTime) {
// //     TimedQueue *timedQueue = (TimedQueue *) malloc(sizeof(TimedQueue));
// //     timedQueue->queue = newQueue();
// //     timedQueue->time = decisionTime;
// // }


// // void freeTimedQueue(TimedQueue **timedQueue) {
// //     //freeNodeQueue(&((*timedQueue)->queue));
// //     free(*timedQueue);
// //     *timedQueue = NULL;
// // }


// // void initTimedQueues(PARAM_TYPE queuesSize, TimedQueue *timedQueues[], unsigned int decisionTime) {
// //     for (int i = 0; i < queuesSize; ++i) {
// //         timedQueues[i] = newTimedQueue(decisionTime);
// //     }
// // }


// // void freeTimedQueues(PARAM_TYPE queuesSize, TimedQueue *timedQueues[]) {
// //     for (int i = 0; i < queuesSize; ++i) {
// //         freeTimedQueue(&timedQueues[i]);
// //     }
// // }


// Patient *acceptNewPatient(PARAM_TYPE queueSize, TimedQueue *timedQueues[], PARAM_TYPE professionCount, PARAM_TYPE *chosenNum) {
//     // unsigned char pFoundPatient = rand() % 100;
//     // if (pFoundPatient < 50) {
//     //     return NULL;
//     // }
//     PARAM_TYPE chosenIndex = rand() % queueSize;
//     Queue *chosenQueue = timedQueues[chosenIndex]->queue;
//     if (!queueIsFull(chosenQueue)) {
//         unsigned char pSick = rand() % 100;
//         unsigned int disease = rand() % professionCount + 1;
//         Patient *patient = newPatient(pSick, disease, 0, 0);
//         *chosenNum = chosenIndex + 1;
//         enqueue(chosenQueue, patient);
//         return patient;
//     }
//     else {
//         PARAM_TYPE foundIndex = -1;
//         for (PARAM_TYPE i = chosenIndex + 1; i < queueSize; ++i) {
//             if (!queueIsFull(timedQueues[i]->queue)) {
//                 foundIndex = i;
//             }
//         }
//         for (PARAM_TYPE i = 0; i < chosenIndex; ++i) {
//             if (!queueIsFull(timedQueues[i]->queue)) {
//                 foundIndex = i;
//             }
//         }
//         if (foundIndex != -1) {
//             unsigned char pSick = rand() % 100;
//             unsigned int disease = rand() % professionCount + 1;
//             Patient *patient = newPatient(pSick, disease, 0, 0);
//             *chosenNum = chosenIndex + 1;
//             enqueue(timedQueues[foundIndex]->queue, patient);
//             return patient;
//         }
//         else {
//             return NULL;
//         }
//     }
// }


// FILE *inputFile(char type[], char fileMsg[]) {
//     FILE *file = NULL;
//     printf("\n\nĮveskite %s failą: ", fileMsg);
//     char filename[FILENAME_MAX];
//     fgets(filename, FILENAME_MAX, stdin);
//     fixFgetsStr(filename);
//     file = fopen(filename, type);
//     if (file == NULL) {
//         printf("\n\nĮvestas failas neegzistuoja, išeinama.");
//         printf("\nProgramos pabaiga.");
//         exit(EXIT_FAILURE);
//     }
//     else {
//         return file;
//     }
// } 



int main() {
    printf("\n\nPoliklinikos modeliavimo programa.");
    FILE *paramFile = inputFile("r", "parametrų");

    PARAM_TYPE modelTime;
    PARAM_TYPE specCount;
    PARAM_TYPE professionCount;
    PARAM_TYPE docCount;
    PARAM_TYPE docSalary;
    PARAM_TYPE docDecisionTime;
    PARAM_TYPE specSalary;
    PARAM_TYPE specDecisionTime;
    PARAM_TYPE *params[PARAMS_COUNT] = {
        &modelTime, 
        &specCount,
        &professionCount,
        &docCount,
        &docSalary,
        &docDecisionTime,
        &specSalary,
        &specDecisionTime
    };

    char readSuccess = readParams(paramFile, params);
    fclose(paramFile);

    char paramError = 0;
    if (readSuccess) {
        if (professionCount > specCount) {
            printf("\neNekorektiški parametrai - specialistų profesijų daugiau už specialistų kiekį.");
            paramError = 1;
        }
        if (docDecisionTime > specDecisionTime) {
            printf("\nNekorektiški parametrai - apylinkės gydytojo sprendimo priėmimo laikas mažesnis už specialisto.");
            paramError = 1;
        }
        if (specSalary < docSalary) {
            printf("\nNekorektiški parametrai - specialisto atlyginimas mažesnis už apylinkės gydytojo.");
            paramError = 1;
        }
        if (arrayHasZero(PARAMS_COUNT, params)) {
            printf("\nVienas iš parametrų yra 0.");
            paramError = 1;
        }
        if (professionCount == 1) {
            printf("\nProfesijų sk. - 1. Nedirba tik įviaurių sričių specialistai.");
        }
    }
    else {
        printf("\nPer mažai parametrų arba netinkamas formatas.");
        paramError = 1;
    }
    if (paramError) {
        printf("\nProgramos pabaiga.");
        exit(EXIT_FAILURE);
    }


    FILE *procFile = inputFile("w", "išvesties");

    srand(time(NULL));

    TimedQueue *specQueues[specCount];
    initTimedQueues(specCount, specQueues, specDecisionTime);


    PARAM_TYPE patientNum = 0;
    PARAM_TYPE waitTimeMax = 0;
    PARAM_TYPE waitTimeMin = modelTime;
    BigInteger specWorkSalary = bint_mul(int_to_bint(specSalary), int_to_bint(modelTime));
    BigInteger clinicBudget = bint_mul(specWorkSalary, int_to_bint(specCount));
    long double waitTimeSum = 0;
    BigInteger discontent = string_to_bint("0");

    // allocate char space for params and results
    {
        char buffer[900] = {' '};
        buffer[899] = '\0';
        fprintf(procFile, "%899s", buffer);
    }
    fprintf(procFile, "\n\n\n\n\n****************** PROCESAS 1 ******************\n\n\n");
    for (PARAM_TYPE t = 1; t <= modelTime; ++t) {
        fprintf(procFile, "\n\nLaikas = %u:", t);
        PARAM_TYPE chosenNum;
        Patient *patient = acceptNewPatient(specCount, specQueues, professionCount, &chosenNum);
        if (patient != NULL) {
            patient->waitStart = t;
            ++patientNum;
            patient->number = patientNum;
            fprintf(procFile, "\nAtėjo pacientas %u ir atsistojo į specialisto %u eilę.", patient->number, chosenNum);
        }
        else {
            fprintf(procFile, "\nNėra naujų pacientų - visos eilės pilnos.");
        }
        
        for (PARAM_TYPE i = 0; i < specCount; ++i) {
            Queue *queue = specQueues[i]->queue;
            if (queueIsEmpty(queue)) {
                specQueues[i]->time = specDecisionTime;
                continue;
            }
            if (specQueues[i]->time > 0) {
                --(specQueues[i]->time);
                continue;
            }
            discontent = bint_add(discontent, int_to_bint(queue->itemCount));
            if (queuePeek(queue)->directed) {
                queuePeek(queue)->directed = 0;
                continue;
            }
            specQueues[i]->time = specDecisionTime;
            Patient *patient = dequeue(queue);
            fprintf(procFile, "\nPaciento %u eilė pas specialistą %u: ", patient->number, i + 1);
            if (patient->pSick < 50) {
                fprintf(procFile, "sveikas.");
                PARAM_TYPE waitTime = t - patient->waitStart;
                waitTimeSum += waitTime;
                if (waitTime > waitTimeMax) {
                    waitTimeMax = waitTime;
                }
                if (waitTime < waitTimeMin) {
                    waitTimeMin = waitTime;
                }
                freePatient(&patient);
                continue;
            }
            int deviation = patient->disease - ((i + 1) % professionCount);
            //fprintf(procFile, "\ndis %u\ndev %d\nprof %d\n", patient->disease, deviation, professionCount);
            if ((deviation == 0) || (deviation == professionCount) || (deviation == -professionCount)) {
                fprintf(procFile, "pagydomas.");
                PARAM_TYPE waitTime = t - patient->waitStart;
                waitTimeSum += waitTime;
                if (waitTime > waitTimeMax) {
                    waitTimeMax = waitTime;
                }
                if (waitTime < waitTimeMin) {
                    waitTimeMin = waitTime;
                }
                freePatient(&patient);
            }
            else {
                PARAM_TYPE specIndex = -1;
                PARAM_TYPE nearestSpecIndex = i + deviation;
                // finding the right specialist
                for (PARAM_TYPE j = nearestSpecIndex; j < specCount; j += professionCount) {
                    if (!queueIsFull(specQueues[j]->queue)) {
                        specIndex = j;
                        break;
                    }
                }
                if (specIndex == -1) {
                    for (PARAM_TYPE j = patient->disease - 1; j < nearestSpecIndex; j += professionCount) {
                        if (!queueIsFull(specQueues[j]->queue)) {
                            specIndex = j;
                            break;
                        }
                    }
                }
                if (specIndex != -1) {
                    //printf("\nligai %u surandom spec. %u", patient->disease, specIndex+1);
                    enqueue(specQueues[specIndex]->queue, patient);
                    fprintf(procFile, "nukreipiamas pas specialistą %u.", specIndex + 1);
                    if (queueLength(specQueues[specIndex]->queue) > 0) {
                        patient->directed = 1;
                    }
                }
                else {
                    fprintf(procFile, "specialistų eilės pilnos - išeinama.");
                    freePatient(&patient);
                }
            }
        }
    }

    freeTimedQueues(specCount, specQueues);


    TimedQueue *specQueues2[specCount];
    initTimedQueues(specCount, specQueues2, specDecisionTime);
    TimedQueue *docQueues[docCount];
    initTimedQueues(docCount, docQueues, docDecisionTime);

    PARAM_TYPE patientNum2 = 0;
    PARAM_TYPE waitTimeMax2 = 0;
    PARAM_TYPE waitTimeMin2 = modelTime;
    BigInteger docWorkSalary = bint_mul(int_to_bint(docSalary), int_to_bint(modelTime));
    BigInteger clinicBudget2 = bint_add(bint_mul(docWorkSalary, int_to_bint(specCount)), clinicBudget);
    long double waitTimeSum2 = 0;
    BigInteger discontent2 = string_to_bint("0");


    fprintf(procFile, "\n\n\n\n\n****************** PROCESAS 2 ******************\n\n\n");
    for (PARAM_TYPE t = 1; t <= modelTime; ++t) {
        fprintf(procFile, "\n\nLaikas = %u:", t);
        PARAM_TYPE chosenNum;
        Patient *patient = acceptNewPatient(docCount, docQueues, professionCount, &chosenNum);
        if (patient != NULL) {
            patient->waitStart = t;
            ++patientNum2;
            patient->number = patientNum2;
            fprintf(procFile, "\nAtėjo pacientas %u ir atsistojo į gydytojo %u eilę.", patient->number, chosenNum);
        }
        else {
            fprintf(procFile, "\nNėra naujų pacientų - visos gydytojų eilės pilnos.");
        }
        
        for (PARAM_TYPE i = 0; i < docCount; ++i) {
            Queue *queue = docQueues[i]->queue;
            if (queueIsEmpty(queue)) {
                docQueues[i]->time = docDecisionTime;
                continue;
            }
            if (docQueues[i]->time > 0) {
                --(docQueues[i]->time);
                continue;
            }
            discontent2 = bint_add(discontent2, int_to_bint(queue->itemCount));
            if (queuePeek(queue)->directed) {
                queuePeek(queue)->directed = 0;
                continue;
            }
            docQueues[i]->time = docDecisionTime;
            Patient *patient = dequeue(queue);
            fprintf(procFile, "\nPaciento %u eilė pas gydyotją %u: ", patient->number, i + 1);
            if (patient->pSick < 50) {
                fprintf(procFile, "sveikas.");
                PARAM_TYPE waitTime = t - patient->waitStart;
                waitTimeSum2 += waitTime;
                if (waitTime > waitTimeMax2) {
                    waitTimeMax2 = waitTime;
                }
                if (waitTime < waitTimeMin2) {
                    waitTimeMin2 = waitTime;
                }
                freePatient(&patient);
                continue;
            }

            // Find correct specialist with lowest index
            PARAM_TYPE minIndex = patient->disease - 1;
            for (PARAM_TYPE j = minIndex + professionCount; j < specCount; j += professionCount) {
                if (queueLength(specQueues2[j]->queue) < queueLength(specQueues2[minIndex]->queue)) {
                    minIndex = j;
                }
            }
            if (!queueIsFull(specQueues2[minIndex]->queue)) {
                fprintf(procFile, "nukreipiamas pas specialistą %u.", minIndex + 1);
                enqueue(specQueues2[minIndex]->queue, patient);
                if (queueLength(specQueues2[minIndex]->queue) > 0) {
                    patient->directed = 1;
                }
            }
            else {
                fprintf(procFile, "reikiamų specialistų eilės pilnos - išeinama.");
                freePatient(&patient);
            }
        }

        for (PARAM_TYPE i = 0; i < specCount; ++i) {
            Queue *queue = specQueues2[i]->queue;
            if (queueIsEmpty(queue)) {
                specQueues2[i]->time = specDecisionTime;
                continue;
            }
            if (specQueues2[i]->time > 0) {
                --(specQueues2[i]->time);
                continue;
            }
            discontent2 = bint_add(discontent2, int_to_bint(queue->itemCount));
            if (queuePeek(queue)->directed) {
                queuePeek(queue)->directed = 0;
                continue;
            }
            specQueues2[i]->time = specDecisionTime;
            Patient *patient = dequeue(queue);
            fprintf(procFile, "\nPaciento %u eilė pas specialistą %u: pagydomas.", patient->number, i + 1);
            PARAM_TYPE waitTime = t - patient->waitStart;
            waitTimeSum2 += waitTime;
            if (waitTime > waitTimeMax2) {
                waitTimeMax2 = waitTime;
            }
            if (waitTime < waitTimeMin2) {
                waitTimeMin2 = waitTime;
            }
            freePatient(&patient);
        }
    }

    freeTimedQueues(specCount, specQueues2);
    freeTimedQueues(docCount, docQueues);


    rewind(procFile);

    fprintf(procFile,
        "ĮVESTI PARAMETRAI:\n\n"
        "1. Modeliavimo laikas:                                 %u\n"
        "2. Specialistų sk.:                                    %u\n"
        "3. Skirtingų profesijų sk.:                            %u\n"
        "4. Apylinkės gydytojų sk.                              %u\n"
        "5. Apylinkės gydytojo atlyginimas per laiko vienetą.   %u\n"
        "6. Apylinkės gydytojo sprendimo priėmimo laikas.       %u\n"
        "7. Specialisto atlyginimas per laiko vienetą.          %u\n"
        "8. Specialisto sprendimo priėmimo laikas.              %u\n"
        ,
        modelTime,
        specCount,
        professionCount,
        docCount,
        docSalary,
        docDecisionTime,
        specSalary,
        specDecisionTime
    );

    long double waitTimeAvg = waitTimeSum / patientNum;

    fprintf(procFile,
        "\n\nPROCESO 1 REZULTATAI:\n\n"
        "1. Poliklinikos biudžetas:         %s\n"
        "2. Minimalus aptarnavimo laikas:   %u\n"
        "3. Vidutinis aptarnavimo laikas:   %.2Lf\n"
        "4. Maksimalus aptarnavimo laikas:  %u\n"
        ,
        bint_to_string(clinicBudget),
        waitTimeMin,
        waitTimeAvg,
        waitTimeMax
    );

    printf(
        "\n\nPROCESO 1 REZULTATAI:\n\n"
        "1. Poliklinikos biudžetas:         %s\n"
        "2. Minimalus aptarnavimo laikas:   %u\n"
        "3. Vidutinis aptarnavimo laikas:   %.2Lf\n"
        "4. Maksimalus aptarnavimo laikas:  %u\n"
        ,
        bint_to_string(clinicBudget),
        waitTimeMin,
        waitTimeAvg,
        waitTimeMax
    );

    long double waitTimeAvg2 = waitTimeSum2 / patientNum2;

    fprintf(procFile,
        "\n\nPROCESO 2 REZULTATAI:\n\n"
        "1. Poliklinikos biudžetas:         %s\n"
        "2. Minimalus aptarnavimo laikas:   %u\n"
        "3. Vidutinis aptarnavimo laikas:   %.2Lf\n"
        "4. Maksimalus aptarnavimo laikas:  %u\n"
        ,
        bint_to_string(clinicBudget2),
        waitTimeMin2,
        waitTimeAvg2,
        waitTimeMax2
    );

    printf(
        "\n\nPROCESO 2 REZULTATAI:\n\n"
        "1. Poliklinikos biudžetas:         %s\n"
        "2. Minimalus aptarnavimo laikas:   %u\n"
        "3. Vidutinis aptarnavimo laikas:   %.2Lf\n"
        "4. Maksimalus aptarnavimo laikas:  %u\n"
        ,
        bint_to_string(clinicBudget2),
        waitTimeMin2,
        waitTimeAvg2,
        waitTimeMax2
    );

    printf("\n\nProgramos pabaiga.");

    return 0;
}